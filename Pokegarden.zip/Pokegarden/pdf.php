<?php
require "conexion_tienda.php";
    $db = new Database();
    $conn =$db->conectar(); 
    $sql = $conn->prepare("SELECT * FROM carro");
    $sql->execute();
    $resultado = $sql->fetchAll(PDO::FETCH_ASSOC); 
    $dato = $_GET["dato"];
    $cli = $conn->prepare("SELECT nombre,email FROM cliente WHERE id_cliente = '$dato' ");
    $cli->execute();
    $res = $cli->fetchAll(PDO::FETCH_ASSOC);

    ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://localhost/pokegarden/estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>PokeGarden</title>
</head>
<body
style="
background-image: none;
"
>
    <section>
        <table class="tabla">
            <tr><th>ID del Cliente</th><th>ID del producto</th><th>Nombre</th><th>Precio</th><th>Cantidad</th></tr>
            <?php foreach($resultado as $row){ ?>
            <tr>
                <td><?php echo $dato; ?></td>
                <td><?php echo $row['id_producto']; ?></td>
                <td><?php echo $row['nombre_p']; ?></td>
                <td><?php echo $row['precio_p']; ?></td>
                <td><?php echo $row['Cantidad']; ?></td>
            </tr>
            <?php }?>
        </table>
        <br>
        <br>
        <table class="tabla">
        <tr><th>Nombre</th><th>Email</th></tr>
        <?php foreach($res as $row){?>
                <tr>
                    <td><?php echo $row['nombre'];?></td>
                    <td><?php echo $row['email'];?></td>
                </tr>
            <?php } ?>
        </table>
    </section>
</body>
<body>
    
</body>
</html>
<?php 

$html = ob_get_clean();

require_once '../Pokegarden/DOMpdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnable' => true ));
$dompdf->setOptions($options);

$dompdf->loadhtml($html);

$dompdf->setPaper('letter');
//$dompdf->setPaper('A4','landscape');

$dompdf->render();

$dompdf->stream("archivo.pdf", array("Attachment" => false));

?>