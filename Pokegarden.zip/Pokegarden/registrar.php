<?php
include 'conexion.php';

$nombre = $_POST['nom'];
$telefono = $_POST['tel'];
$email = $_POST['email']; 
$pass = $_POST['pass'];

$sql = mysqli_query($con, "INSERT INTO cliente (id_cliente,nombre,telefono,email,contrasena) values (0,'$nombre','$telefono','$email','$pass')");

if($sql){
    echo "Usuario Registrado";
    header("location: login.html");
}
?>
