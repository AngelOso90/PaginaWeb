<?php
include "conexion.php";

if(isset($_POST["btn_buscar_cliente"])){
        $idp = $_POST['idp'];
        $search = "select * from cliente where id_cliente='$idp'";
        $consulta = $con->query($search);
        while($row = $consulta->fetch_array()){
            echo $row['id_cliente'].' / '.$row['nombre'].' / '.$row['telefono'].' / '.$row['email'].' / '.$row['contrasena'].'<br>';
        }
    
}else if(isset($_POST["btn_todo_cliente"])){
        $search = "select * from cliente";
        $consulta = $con->query($search);
}
?>
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>PokeGarden</title>
</head>
<body>
    <header>
        <nav class="nav">
            <div class="logo"><a href="Admin_index.php">PokeGarden</a></div>
            <ul class="menu">
                <li><a href="Admin_Productos.php">Productos</a></li>
                <li><a href="Admin_Clientes.php">Clientes</a></li>
                <li><a href="index_poke.html">Cerrar Sesión</a></li>
                <li><img class="usu"src="Imagenes/usuario.png" alt="Admin"></li>
            </ul>
        </nav>
    </header>
    <section class="cuerpo">
        <table class="tabla">
            <tr><th>ID</th><th>Nombre</th><th>Telefono</th><th>E-Mail</th><th>Contraseña</th></tr>
            <?php foreach($consulta as $row){ ?>
            <tr>
                <td><?php echo $row['id_cliente']; ?></td>
                <td><?php echo $row['nombre']; ?></td>
                <td><?php echo $row['telefono']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['contrasena']; ?></td>
            </tr>
            <?php }?>
        </table>
        <a href="Admin_Clientes.php">Regresar</a>
    </section>
</body>
</html>