<?php
require "conexion_tienda.php";
    $id = $_GET['var'];
    $dato = $_GET['dato'];
    $db = new Database();
    $conn =$db->conectar(); 
    $sql = $conn->prepare("SELECT id_producto,nombre, precio FROM producto  where id_producto='$id'");
    $sql->execute();
    $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
?>
<html>
    <?php foreach($resultado as $row){ ?>
            <?php
            if($row['cantidad']==null){
                $id_p = $row['id_producto'];
                $nom_p = $row['nombre'];
                $pre_p = $row['precio'];
                $insert = $conn->prepare("INSERT INTO carro (id_cliente, id_producto, nombre_p, precio_p,cantidad) values ('$dato','$id_p','$nom_p','$pre_p',1);");
                $insert->execute();
                if($insert){
                    header("Location:cliente_producto.php?dato=$dato");
                }
            }else{
              $catidad = $row['cantidad'];
              $catidad = $catidad+1;
              $id_p = $row['id_producto'];
                $nom_p = $row['nombre'];
                $pre_p = $row['precio'];
                $insert = $conn->prepare("INSERT INTO carro (id_cliente, id_producto, nombre_p, precio_p,cantidad) values ('$dato','$id_p','$nom_p','$pre_p',1);");
                $insert->execute();
                if($insert){
                    header("Location:carrito_mostrar.php?dato=$dato");
                } 
            }
                
            ?> 
        <?php }?>
</html>