
<?php
include "conexion.php";

$url = $_POST['url'];
$nomb = $_POST['nom'];
$pre = $_POST['pre'];
$des = $_POST['des']; 

$insert = mysqli_query($con,"INSERT INTO Producto (id_producto, link, nombre, precio, descripcion) values (0,'$url','$nomb','$pre','$des');");
if($insert){
header("location:Admin_Productos.php");
}
else{
    echo "No se pudo";
}
?>