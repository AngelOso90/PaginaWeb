<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>PokeGarden</title>
</head>
<body>
    <header>
        <nav class="nav">
            <div class="logo"><a href="Admin_index.php">PokeGarden</a></div>
            <ul class="menu">
                <li><a href="Admin_Productos.php">Productos</a></li>
                <li><a href="Admin_Clientes.php">Clientes</a></li>
                <li><a href="index_poke.html">Cerrar Sesión</a></li>
                <li><img class="usu"src="Imagenes/usuario.png" alt="Admin"></li>
            </ul>
        </nav>
    </header>
    <section class="cuerpo">

    <div>
            <form method="POST" action="ingresar_producto.php">
            <h2>Ingresar Producto</h2>
            <label>
                <input placeholder="URL Imagen" type="text" id="url" name="url">
            </label>
            <label>
                <input placeholder="Nombre" type="text" id="nom" name="nom">
            </label>
            <label>
                <input placeholder="Precio" type="text" id="pre" name="pre">
            </label>
            <label>
                <input placeholder="Descripción" type="text" id="des" name="des">
            </label>
            </label>
            <button id="btn_ingresar_producto"> Ingresar</button>
        </form>
    </div>
    <div>
        <form method="POST" action="Editar_producto.php">
            <h2>Editar Producto</h2>
            <label>
                <input placeholder="ID" type="text" id="id" name="id">
            </label>
            <label>
                <input placeholder="URL Imagen" type="text" id="url" name="url">
            </label>
            <label>
                <input placeholder="Nombre" type="text" id="nom" name="nom">
            </label>
            <label>
                <input placeholder="Precio" type="text" id="pre" name="pre">
            </label>
            <label>
                <input placeholder="Descripción" type="text" id="des" name="des">
            </label>
            </label>
            <button id="btn_editar_producto" name="btn_editar_producto"> Editar</button>
        </form>
    </div>
    <div>
        <form method="POST" action="eliminar_producto.php">
            <h2>Eliminar Producto</h2>
            <label>
                <input placeholder="ID" type="text" id="idp" name="idp">
            </label>
            </label>
            <button id="btn_eliminar_producto" name="btn_eliminar_producto"> Eliminar</button>
        </form>
    </div>
    <div>
    <form method="POST" action="Buscar_producto.php">
            <h2>Buscar Producto</h2>
            <label>
                <input placeholder="ID" type="text" id="idp" name="idp">
            </label>
            </label>
            <button id="btn_buscar_producto" name="btn_buscar_producto"> Buscar</button>
            <br>
            <button id="btn_todo_producto" name="btn_todo_producto"> Mostrar tabla completa</button>
        </form>
    </div>
    </section>
</body>
</html>