<?php
include "conexion.php";

if(isset($_POST["btn_eliminar_cliente"])){
        $idp = $_POST['idp'];
        $delete = "DELETE FROM cliente where id_cliente=?";
        $sentencia = mysqli_prepare($con,$delete);
        mysqli_stmt_bind_param($sentencia,"i",$idp);
        mysqli_stmt_execute($sentencia);
        $comprobacion = mysqli_stmt_affected_rows($sentencia);
    if($comprobacion == 1){
        echo "Eliminado";
    }
    else{
        echo "No se pudo";
    }
}

?>