<?php 
require "conexion_tienda.php";
$db = new Database();
$conn =$db->conectar(); 
$sql = $conn->prepare("SELECT id_producto, link, nombre, precio FROM producto");
$sql->execute();
$resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
$dato = $_GET["dato"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>PokeGarden</title>
</head>
<body>
    <header>
        <nav class="nav">
            <div class="logo"><a href="cliente_index.php?dato=<?php echo $dato ?>">PokeGarden</a></div>
            <ul class="menu">
                <li><a href="cliente_ubic.php?dato=<?php echo $dato?>">Ubicación</a></li>
                <li><a href="cliente_producto.php?dato=<?php echo $dato ?>">Productos</a></li>
                <li><a href="index_poke.html">Cerrar Sesión</a></li>
                <li><a href="carrito_mostrar.php?dato=<?php echo $dato ?>" ><img class="usu" src="Imagenes/carrito.png" alt=""></a></li>
                <li><img class="usu"src="Imagenes/usuario.png" alt=""></li>
            </ul>
        </nav>
    </header>
    <section class="cuerpo">
    <p><?php echo $dato?></p>
    <h1>Peluches</h1>
    <br>
    <form method="POST" action="busqueda.php">
        <h2>Buscar Producto</h2>
            <label>
                <i><img class="icon" src="./Imagenes/pikacho-user-icon.png" alt=""></i>
                <input placeholder="Nombre" type="text" id="nombre" name="nombre">
            </label>
            </label>
            <button id="busqueda" name="busqueda"> Buscar</button>
        </form>
        
        <br>
        <div class="cont_index">
        <?php foreach($resultado as $row){ ?>
            <?php
                $name = $row['link']; 
                $imagen = "Imagenes/Peluches/".$name; 
            ?> 
        <div class="cont_carta">
            <div class="cont_img">
            <img src="<?php echo $imagen; ?>" >
            </div>
            <div class="cont_texto_c">
            <h2 style="font-size: 1.5em; margin-top: 0;  margin-left: 0.5em;"><?php echo $row['nombre'];?></h2>
            <p style="font-size: 1.3em; margin-top: 0.5em; margin-left: 0.5em;"> $ <?php echo $row['precio'];?>"</p>
            <div class="btn_agregar">
            <a href="carrito.php?var=<?php echo $row['id_producto']; ?>&dato=<?php echo $dato; ?>">Agregar</a>  
            </div>   
        </div>
        </div>
        <?php }?>
        </div>
    </section>
</body>
</html>