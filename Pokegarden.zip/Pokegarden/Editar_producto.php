<?php
include "conexion.php";
        $url = $_POST['url'];
        $nomb = $_POST['nom'];
        $pre = $_POST['pre'];
        $des = $_POST['des']; 
        $id = $_POST['id'];
        
        $update = "UPDATE Producto SET link = '$url', nombre = '$nomb', precio = '$pre', descripcion = '$des' where id_producto=?";
        $sentencia = mysqli_prepare($con,$update);
        mysqli_stmt_bind_param($sentencia,"i",$id);
        mysqli_stmt_execute($sentencia);
        $comprobacion = mysqli_stmt_affected_rows($sentencia);
    if($comprobacion == 1){
        header("location:Admin_Productos.php");

    }
    else{
        echo "No se pudo";
    }
?>
