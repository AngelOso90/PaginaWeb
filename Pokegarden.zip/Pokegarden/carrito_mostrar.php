<?php
require "conexion_tienda.php";
    $db = new Database();
    $conn =$db->conectar(); 
    $sql = $conn->prepare("SELECT * FROM carro");
    $sql->execute();
    $resultado = $sql->fetchAll(PDO::FETCH_ASSOC); 
    $dato = $_GET["dato"];
    $cli = $conn->prepare("SELECT nombre,email FROM cliente WHERE id_cliente = '$dato' ");
    $cli->execute();
    $res = $cli->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://localhost/pokegarden/estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>PokeGarden</title>
</head>
<body>
    <header>
        <nav class="nav">
            <div class="logo"><a href="cliente_index.php?dato=<?php echo $dato ?>">PokeGarden</a></div>
            <ul class="menu">
                <li><a href="cliente_ubic.php?dato=<?php echo $dato?>">Ubicación</a></li>
                <li><a href="cliente_producto.php?dato=<?php echo $dato ?>">Productos</a></li>
                <li><a href="index_poke.html">Cerrar Sesión</a></li>
                <li><a href="carrito_mostrar.php?dato=<?php echo $dato ?>" ><img class="usu" src="Imagenes/carrito.png" alt=""></a></li>
                <li><img class="usu"src="Imagenes/usuario.png" alt=""></li>
            </ul>
        </nav>
    </header>
    <section class="cuerpo">
    <p><?php echo $dato?></p>
        <table class="tabla">
            <tr><th>ID del Cliente</th><th>ID del producto</th><th>Nombre</th><th>Precio</th><th>Cantidad</th><th></th></tr>
            <?php foreach($resultado as $row){ ?>
            <tr>
                <td><?php echo $dato; ?></td>
                <td><?php echo $row['id_producto']; ?></td>
                <td><?php echo $row['nombre_p']; ?></td>
                <td><?php echo $row['precio_p']; ?></td>
                <td><?php echo $row['Cantidad']; ?></td>
                <td><a href="carrito_eliminar.php?var=<?php echo $row['id_producto'];?>">Eliminar</a></td>
            </tr>
            <?php }?>
        </table>
        <table class="tabla">
        <tr><th>Nombre</th><th>Email</th></tr>
        <?php foreach($res as $row){?>
                <tr>
                    <td><?php echo $row['nombre'];?></td>
                    <td><?php echo $row['email'];?></td>
                </tr>
            <?php } ?>
        </table>
        <a href="cliente_producto.php?dato=<?php echo $dato ?>">Regresar</a>
        <a href="envio.php?dato=<?php echo $dato ?>">Imprimir</a>
    </section>
</body>
</html>