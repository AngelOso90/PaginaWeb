<?php
include "conexion.php";
        $nom = $_POST['nom'];
        $tel = $_POST['tel'];
        $email = $_POST['email'];
        $pass = $_POST['pass']; 
        $id = $_POST['id'];
        
        $update = "UPDATE Cliente SET nombre = '$nom', telefono = '$tel', email = '$email', contrasena = '$pass' where id_cliente=?";
        $sentencia = mysqli_prepare($con,$update);
        mysqli_stmt_bind_param($sentencia,"i",$id);
        mysqli_stmt_execute($sentencia);
        $comprobacion = mysqli_stmt_affected_rows($sentencia);
    if($comprobacion == 1){
        echo "Editado";
    }
    else{
        echo "No se pudo";
    }


?>