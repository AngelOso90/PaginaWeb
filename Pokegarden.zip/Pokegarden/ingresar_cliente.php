<?php 
        include "conexion.php";

        $nom = $_POST['nom'];
        $tel = $_POST['tel'];
        $email = $_POST['email'];
        $pass = $_POST['pass']; 
        
        $insert = mysqli_query($con,"INSERT INTO Cliente (id_cliente, nombre, telefono, email, contrasena) values (0,'$nom','$tel','$email','$pass');");
        if($insert){
            echo "Insertado";
        }
        else{
            echo "No se pudo";
        }
    ?>