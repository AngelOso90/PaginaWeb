<?php
include 'conexion.php';
$email = $_POST["email"];
$pass = $_POST["pass"];


$sql = $con->query("select * from cliente where email='$email' and contrasena='$pass'");
$query = "SELECT id_cliente FROM cliente WHERE email='$email'";
$result = $con->query($query);
    $row = $result->fetch_assoc();
    $dato = $row["id_cliente"];
if($sql->fetch_object()){
    header("location:cliente_index.php?dato=".urldecode($dato));
}else if($email == "Admin@pokegarden.com" && $pass == "Seguro"){
    header("location:Admin_index.php");
}else{
    echo "NEL";
}   
?>
