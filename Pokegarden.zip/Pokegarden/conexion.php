<?php
$server = "localhost"; 
$database = "pokegarden";
$username = "angel";
$password = "1234";

$con = mysqli_connect($server,$username,$password,$database);
if($con){
    header("index.html");
}
?>
