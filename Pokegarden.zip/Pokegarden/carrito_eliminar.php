<?php
    require "conexion_tienda.php";
    $id = $_GET['var'];
    $db = new Database();
    $conn =$db->conectar(); 
    $sql = $conn->prepare("DELETE FROM carro WHERE id_producto='$id'");
    $sql->execute();
    if($sql){
        header("Location:carrito_mostrar.php"); 
    }
?>
