<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>PokeGarden</title>
</head>
<body>
    <header>
        <nav class="nav">
            <div class="logo"><a href="Admin_index.php">PokeGarden</a></div>
            <ul class="menu">
                <li><a href="Admin_Productos.php">Productos</a></li>
                <li><a href="Admin_Clientes.php">Clientes</a></li>
                <li><a href="index_poke.html">Cerrar Sesión</a></li>
                <li><img class="usu"src="Imagenes/usuario.png" alt="Admin"></li>
            </ul>
        </nav>
    </header>
    <section class="cuerpo">
        <div>
        <form method="POST" action="ingresar_cliente.php">
            <h2>Ingresar Nuevo Cliente</h2>
            <label>
                <input placeholder="Nombre" type="text" id="nom" name="nom">
            </label>
            <label>
                <input placeholder="Telefono" type="text" id="tel" name="tel">
            </label>
            <label>
                <input placeholder="E-mail" type="email" id="email" name="email">
            </label>
            <label>
                <input placeholder="Contraseña" type="password" id="pass" name="pass">
            </label>
            </label>
            <button id="btn_reg_cliente"> Registrar</button>
        </form>
        </div>
        <div>
        <form method="POST" action="Editar_cliente.php">
            <h2>Editar Cliente</h2>
            <label>
                <input placeholder="ID" type="text" id="id" name="id">
            </label>
            <label>
                <input placeholder="Nombre" type="text" id="nom" name="nom">
            </label>
            <label>
                <input placeholder="Telefono" type="text" id="tel" name="tel">
            </label>
            <label>
                <input placeholder="E-mail" type="email" id="email" name="email">
            </label>
            <label>
                <input placeholder="Contraseña" type="password" id="pass" name="pass">
            </label>
            </label>
            <button id="btn_editar_producto" name="btn_editar_producto"> Editar</button>
        </form>
        </div>
        <div>
        <form method="POST" action="eliminar_cliente.php">
            <h2>Eliminar Cliente</h2>
            <label>
                <input placeholder="ID" type="text" id="idp" name="idp">
            </label>
            </label>
            <button id="btn_eliminar_cliente" name="btn_eliminar_cliente"> Eliminar</button>
        </form>
        </div>
        <div>
        <form method="POST" action="Buscar_cliente.php">
            <h2>Buscar Cliente</h2>
            <label>
                <input placeholder="ID" type="text" id="idp" name="idp">
            </label>
            </label>
            <button id="btn_buscar_cliente" name="btn_buscar_cliente"> Buscar</button>
            <br>
            <button id="btn_todo_cliente" name="btn_todo_cliente"> Mostrar tabla completa</button>
        </form>
        </div>

    </section>
</body>
</html>